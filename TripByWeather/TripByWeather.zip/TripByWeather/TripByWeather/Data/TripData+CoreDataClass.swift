//
//  TripData+CoreDataClass.swift
//  TripByWeather
//
//  Created by Fevin Patel on 2023-12-07.
//
//

import Foundation
import CoreData

@objc(TripData)
public class TripData: NSManagedObject {

}
